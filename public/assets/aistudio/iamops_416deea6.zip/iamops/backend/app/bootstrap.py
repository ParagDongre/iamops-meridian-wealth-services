"""Create the first admin without demo data: BOOTSTRAP_ADMIN_EMAIL / BOOTSTRAP_ADMIN_PASSWORD (>=12 chars)."""
import os
from datetime import date
from sqlalchemy import select
from .config import get_settings
from .db import make_engine, make_session_factory
from .models import Identity
from .security import hash_pw
from .services import audit

def main():
    e, p = os.environ["BOOTSTRAP_ADMIN_EMAIL"], os.environ["BOOTSTRAP_ADMIN_PASSWORD"]
    if len(p) < 12: raise SystemExit("Password must be at least 12 characters")
    with make_session_factory(make_engine(get_settings().DATABASE_URL))() as db:
        if db.scalar(select(Identity).where(Identity.app_role == "admin")): print("admin already exists"); return
        i = Identity(employee_id="ADMIN001", full_name="Platform Admin", email=e, department="IT", job_title="IAM Administrator",
                     joining_date=date.today(), app_role="admin", password_hash=hash_pw(p)); db.add(i); db.flush()
        audit.log(db, "bootstrap", "identity_created", i.id, new={"email": e, "app_role": "admin"}); db.commit(); print("admin created")
if __name__ == "__main__": main()
